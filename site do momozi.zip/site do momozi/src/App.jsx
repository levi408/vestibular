import React from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import StudyPlanner from '@/components/StudyPlanner';

function App() {
  return (
    <>
      <Helmet>
        <title>Study Planner - Organize Your Learning Journey</title>
        <meta name="description" content="Complete study planner with interactive calendar, progress tracking, task management, and material repository for Math, Biology, Chemistry, Portuguese, Physics, and Literature." />
      </Helmet>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-100">
        <StudyPlanner />
        <Toaster />
      </div>
    </>
  );
}

export default App;