export const studyPlanData = {
  1: {
    monday: [
      { subject: 'Math', topic: 'Algebra Basics', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Cell Structure', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Atomic Structure', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Grammar Fundamentals', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Mechanics Introduction', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Literary Genres', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Linear Equations', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Cell Division', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Chemical Bonds', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Reading Comprehension', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Newton\'s Laws', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Poetry Analysis', time: '14:00 - 15:30' }
    ]
  },
  2: {
    monday: [
      { subject: 'Math', topic: 'Quadratic Equations', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Genetics Basics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Periodic Table', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Verb Conjugation', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Energy & Work', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Narrative Techniques', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Functions', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'DNA Structure', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Chemical Reactions', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Essay Writing', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Momentum', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Drama Analysis', time: '14:00 - 15:30' }
    ]
  },
  3: {
    monday: [
      { subject: 'Math', topic: 'Trigonometry Basics', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Evolution Theory', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Stoichiometry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Syntax', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Thermodynamics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Modernism', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Logarithms', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Ecology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Acids & Bases', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Literary Devices', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Waves', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Romanticism', time: '14:00 - 15:30' }
    ]
  },
  4: {
    monday: [
      { subject: 'Math', topic: 'Geometry Fundamentals', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Human Anatomy', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Organic Chemistry Intro', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Phonetics', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Optics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Realism', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Statistics', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Photosynthesis', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Hydrocarbons', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Semantics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Electricity Basics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Symbolism', time: '14:00 - 15:30' }
    ]
  },
  5: {
    monday: [
      { subject: 'Math', topic: 'Probability', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Respiration', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Functional Groups', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Discourse Analysis', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Magnetism', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Contemporary Literature', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Sequences & Series', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Nervous System', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Isomerism', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Argumentative Writing', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Circuits', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Critical Theory', time: '14:00 - 15:30' }
    ]
  },
  6: {
    monday: [
      { subject: 'Math', topic: 'Matrices', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Immune System', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Polymers', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Stylistics', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Electromagnetic Induction', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Postmodernism', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Determinants', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Endocrine System', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Biochemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Textual Genres', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Modern Physics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'World Literature', time: '14:00 - 15:30' }
    ]
  },
  7: {
    monday: [
      { subject: 'Math', topic: 'Calculus Introduction', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Reproduction', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Electrochemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Pragmatics', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Quantum Mechanics Intro', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Comparative Literature', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Derivatives', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Biotechnology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Thermochemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Sociolinguistics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Relativity', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Literary Criticism', time: '14:00 - 15:30' }
    ]
  },
  8: {
    monday: [
      { subject: 'Math', topic: 'Integrals', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Molecular Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Chemical Kinetics', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Discourse Markers', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Nuclear Physics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Feminist Literature', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Differential Equations', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Bioinformatics', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Equilibrium', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Text Cohesion', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Particle Physics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Postcolonial Literature', time: '14:00 - 15:30' }
    ]
  },
  9: {
    monday: [
      { subject: 'Math', topic: 'Vector Calculus', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Genomics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Coordination Compounds', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Intertextuality', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Astrophysics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Magical Realism', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Complex Numbers', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Proteomics', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Spectroscopy', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Multimodal Texts', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Cosmology', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Dystopian Literature', time: '14:00 - 15:30' }
    ]
  },
  10: {
    monday: [
      { subject: 'Math', topic: 'Number Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Systems Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Green Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Critical Discourse', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Condensed Matter', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Graphic Novels', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Graph Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Neuroscience', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Nanotechnology', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Digital Literacy', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Biophysics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Digital Literature', time: '14:00 - 15:30' }
    ]
  },
  11: {
    monday: [
      { subject: 'Math', topic: 'Advanced Algebra Review', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Microbiology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Materials Science', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Academic Writing', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Fluid Dynamics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Ecocriticism', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Optimization', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Virology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Analytical Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Research Methods', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Acoustics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Translation Studies', time: '14:00 - 15:30' }
    ]
  },
  12: {
    monday: [
      { subject: 'Math', topic: 'Linear Programming', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Immunology Advanced', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Computational Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Rhetoric', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Plasma Physics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Performance Studies', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Topology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Pharmacology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Photochemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Corpus Linguistics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Geophysics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Film Studies', time: '14:00 - 15:30' }
    ]
  },
  13: {
    monday: [
      { subject: 'Math', topic: 'Combinatorics', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Toxicology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Supramolecular Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Cognitive Linguistics', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Atmospheric Physics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Cultural Studies', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Game Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Epidemiology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Medicinal Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Applied Linguistics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Oceanography', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Media Studies', time: '14:00 - 15:30' }
    ]
  },
  14: {
    monday: [
      { subject: 'Math', topic: 'Cryptography', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Conservation Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Environmental Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Psycholinguistics', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Renewable Energy', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Gender Studies', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Chaos Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Marine Biology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Food Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Neurolinguistics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Nanotechnology Physics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Queer Theory', time: '14:00 - 15:30' }
    ]
  },
  15: {
    monday: [
      { subject: 'Math', topic: 'Fractal Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Astrobiology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Forensic Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Historical Linguistics', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Medical Physics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Trauma Studies', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Mathematical Modeling', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Synthetic Biology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Industrial Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Comparative Linguistics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Quantum Computing', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Memory Studies', time: '14:00 - 15:30' }
    ]
  },
  16: {
    monday: [
      { subject: 'Math', topic: 'Numerical Analysis', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Developmental Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Polymer Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Dialectology', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Photonics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Space Studies', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Abstract Algebra', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Stem Cell Biology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Catalysis', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Phonology Advanced', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Spintronics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Animal Studies', time: '14:00 - 15:30' }
    ]
  },
  17: {
    monday: [
      { subject: 'Math', topic: 'Real Analysis', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Evolutionary Development', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Surface Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Morphology Advanced', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Metamaterials', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Thing Theory', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Measure Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Epigenetics', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Crystallography', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Syntax Advanced', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Quantum Optics', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Affect Theory', time: '14:00 - 15:30' }
    ]
  },
  18: {
    monday: [
      { subject: 'Math', topic: 'Functional Analysis', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Chronobiology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Colloid Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Semantics Advanced', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Quantum Information', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'New Materialism', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Algebraic Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Behavioral Ecology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Organometallic Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Pragmatics Advanced', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Topological Insulators', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Posthumanism', time: '14:00 - 15:30' }
    ]
  },
  19: {
    monday: [
      { subject: 'Math', topic: 'Differential Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Population Genetics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Bioinorganic Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Discourse Analysis Advanced', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'String Theory Intro', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Speculative Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Lie Groups', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Molecular Evolution', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Photovoltaic Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Stylistics Advanced', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Dark Matter', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Afrofuturism', time: '14:00 - 15:30' }
    ]
  },
  20: {
    monday: [
      { subject: 'Math', topic: 'Algebraic Topology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Comparative Genomics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Battery Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Textual Criticism', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Dark Energy', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Indigenous Literature', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Category Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Metagenomics', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Fuel Cell Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Philology', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Gravitational Waves', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Disability Studies', time: '14:00 - 15:30' }
    ]
  },
  21: {
    monday: [
      { subject: 'Math', topic: 'Homological Algebra', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Systems Immunology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Click Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Etymology', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Exoplanets', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Cli-Fi', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Representation Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Cancer Biology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'MOF Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Onomastics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Multiverse Theory', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Solarpunk', time: '14:00 - 15:30' }
    ]
  },
  22: {
    monday: [
      { subject: 'Math', topic: 'Harmonic Analysis', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Aging Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Perovskite Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Lexicography', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Hawking Radiation', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Hopepunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Operator Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Regenerative Medicine', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Terminology', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Wormholes', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'New Weird', time: '14:00 - 15:30' }
    ]
  },
  23: {
    monday: [
      { subject: 'Math', topic: 'Stochastic Processes', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Tissue Engineering', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Graphene Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Corpus Analysis', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Time Dilation', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Slipstream', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Ergodic Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Organoid Technology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Carbon Nanotubes', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Computational Linguistics', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Parallel Universes', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Biopunk', time: '14:00 - 15:30' }
    ]
  },
  24: {
    monday: [
      { subject: 'Math', topic: 'Dynamical Systems', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'CRISPR Technology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Dots', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Machine Translation', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Antimatter', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Cyberpunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Bifurcation Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Gene Therapy', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Nanomedicine', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Natural Language Processing', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Supersymmetry', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Steampunk', time: '14:00 - 15:30' }
    ]
  },
  25: {
    monday: [
      { subject: 'Math', topic: 'Knot Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Personalized Medicine', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Smart Materials', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Speech Recognition', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Higgs Boson', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Dieselpunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Spectral Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Precision Medicine', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Self-Healing Materials', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Sentiment Analysis', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Grand Unified Theory', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Atompunk', time: '14:00 - 15:30' }
    ]
  },
  26: {
    monday: [
      { subject: 'Math', topic: 'Morse Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Microbiome Research', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Biomimetic Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Text Mining', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Theory of Everything', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Nanopunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Symplectic Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Optogenetics', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Artificial Photosynthesis', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Information Extraction', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Loop Quantum Gravity', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Biopunk Advanced', time: '14:00 - 15:30' }
    ]
  },
  27: {
    monday: [
      { subject: 'Math', topic: 'Riemannian Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Connectomics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'CO2 Capture Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Question Answering Systems', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'M-Theory', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Mythpunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Complex Manifolds', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Brain-Computer Interfaces', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Hydrogen Economy', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Dialogue Systems', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Holographic Principle', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Silkpunk', time: '14:00 - 15:30' }
    ]
  },
  28: {
    monday: [
      { subject: 'Math', topic: 'Hodge Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Neuroplasticity', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Water Splitting', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Chatbot Development', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Brane Cosmology', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Clockpunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Sheaf Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Neurogenesis', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Artificial Enzymes', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Language Models', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Causal Sets', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Sandalpunk', time: '14:00 - 15:30' }
    ]
  },
  29: {
    monday: [
      { subject: 'Math', topic: 'K-Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Memory Formation', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Molecular Machines', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Neural Networks for NLP', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Emergent Gravity', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Stonepunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Derived Categories', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Consciousness Studies', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'DNA Nanotechnology', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Transformers in NLP', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Quantum Entanglement', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Raypunk', time: '14:00 - 15:30' }
    ]
  },
  30: {
    monday: [
      { subject: 'Math', topic: 'Moduli Spaces', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Artificial Intelligence in Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Molecular Electronics', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'BERT and GPT Models', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Quantum Teleportation', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Nowpunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Quantum Groups', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Computational Biology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Spintronics Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Multimodal AI', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Quantum Cryptography', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Hopepunk Advanced', time: '14:00 - 15:30' }
    ]
  },
  31: {
    monday: [
      { subject: 'Math', topic: 'Noncommutative Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Machine Learning in Genomics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Valleytronics', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'AI Ethics in Language', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Quantum Sensors', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Solarpunk Advanced', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Tropical Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Deep Learning in Medicine', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Twistronics', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Bias in Language Models', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Quantum Networks', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Lunarpunk', time: '14:00 - 15:30' }
    ]
  },
  32: {
    monday: [
      { subject: 'Math', topic: 'Arithmetic Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'AlphaFold & Protein Folding', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Topological Materials', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Explainable AI', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Quantum Simulation', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Tidalpunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Motivic Cohomology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Single-Cell Sequencing', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Materials', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Few-Shot Learning', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Topological Quantum Computing', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Desertpunk', time: '14:00 - 15:30' }
    ]
  },
  33: {
    monday: [
      { subject: 'Math', topic: 'Perfectoid Spaces', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Spatial Transcriptomics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Majorana Fermions', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Zero-Shot Learning', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Anyons', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Oceanpunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Langlands Program', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Organoid Intelligence', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Weyl Semimetals', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Prompt Engineering', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Axion Detection', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Forestpunk', time: '14:00 - 15:30' }
    ]
  },
  34: {
    monday: [
      { subject: 'Math', topic: 'Condensed Mathematics', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Xenobots', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Time Crystals', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Chain-of-Thought Prompting', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Primordial Black Holes', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Swamppunk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Homotopy Type Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Biocomputing', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Skyrmions', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Constitutional AI', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Cosmic Strings', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Icepunk', time: '14:00 - 15:30' }
    ]
  },
  35: {
    monday: [
      { subject: 'Math', topic: 'Infinity Categories', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Living Therapeutics', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Exciton Condensates', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Retrieval-Augmented Generation', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Cosmic Inflation', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Volcanic Punk', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Derived Algebraic Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Cellular Reprogramming', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Polariton Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Multimodal Foundation Models', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Vacuum Decay', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Crystalpunk', time: '14:00 - 15:30' }
    ]
  },
  36: {
    monday: [
      { subject: 'Math', topic: 'Spectral Algebraic Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Morphogenesis Engineering', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Cavity Chemistry', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Emergent Abilities in LLMs', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'False Vacuum', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Mythic Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Pyknotic Sets', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Synthetic Embryology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Vibrational Strong Coupling', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'In-Context Learning', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Boltzmann Brains', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'New Fabulism', time: '14:00 - 15:30' }
    ]
  },
  37: {
    monday: [
      { subject: 'Math', topic: 'Condensed Sets', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Bioelectric Signaling', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Molecular Polaritons', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Instruction Tuning', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Eternal Inflation', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Interstitial Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Analytic Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Planarian Regeneration', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Photonic Molecules', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Alignment Research', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Bubble Universes', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Slipstream Advanced', time: '14:00 - 15:30' }
    ]
  },
  38: {
    monday: [
      { subject: 'Math', topic: 'Prismatic Cohomology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Collective Intelligence', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Coherence in Biology', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Reinforcement Learning from Human Feedback', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Cyclic Cosmology', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Transgressive Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Perfectoid Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Swarm Intelligence', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Biology', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'AI Safety', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Conformal Cyclic Cosmology', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Bizarro Fiction', time: '14:00 - 15:30' }
    ]
  },
  39: {
    monday: [
      { subject: 'Math', topic: 'Tilting Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Emergent Behavior', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Effects in Photosynthesis', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Mechanistic Interpretability', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Ekpyrotic Universe', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Weird Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Diamonds in Geometry', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Self-Organization', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Tunneling in Enzymes', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Scaling Laws', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Brane Worlds', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'New Wave Fabulism', time: '14:00 - 15:30' }
    ]
  },
  40: {
    monday: [
      { subject: 'Math', topic: 'Fargues-Fontaine Curve', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Morphogenetic Fields', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Coherence in Olfaction', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Emergent Capabilities', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Randall-Sundrum Models', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Liminal Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Scholze\'s Work', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Bioelectric Patterns', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Effects in Vision', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Frontier Models', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'ADD Model', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Uncanny Fiction', time: '14:00 - 15:30' }
    ]
  },
  41: {
    monday: [
      { subject: 'Math', topic: 'Condensed Abelian Groups', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Pattern Formation', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Biology Applications', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'AGI Research', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Kaluza-Klein Theory', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Threshold Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Liquid Vector Spaces', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Turing Patterns', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Entanglement in Biology', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Superintelligence Theory', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Compactification', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Ontological Fiction', time: '14:00 - 15:30' }
    ]
  },
  42: {
    monday: [
      { subject: 'Math', topic: 'Solid Modules', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Reaction-Diffusion Systems', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Consciousness', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'AI Consciousness', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Calabi-Yau Manifolds', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Metaphysical Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Analytic Rings', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Complexity Theory', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Orchestrated Objective Reduction', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Machine Consciousness', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Orbifolds', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Existential Fiction', time: '14:00 - 15:30' }
    ]
  },
  43: {
    monday: [
      { subject: 'Math', topic: 'Condensed Ring Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Chaos in Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Microtubule Quantum Processing', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Sentience vs Intelligence', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Mirror Symmetry', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Absurdist Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Six Functor Formalism', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Fractal Biology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Mind Hypothesis', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Qualia Problem', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Heterotic Strings', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Philosophical Fiction', time: '14:00 - 15:30' }
    ]
  },
  44: {
    monday: [
      { subject: 'Math', topic: 'Etale Cohomology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Scale-Free Networks', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Brain Dynamics', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Hard Problem of Consciousness', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Type IIA/IIB Strings', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Phenomenological Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Crystalline Cohomology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Power Laws in Biology', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Cognition', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Integrated Information Theory', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'D-Branes', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Consciousness Fiction', time: '14:00 - 15:30' }
    ]
  },
  45: {
    monday: [
      { subject: 'Math', topic: 'Rigid Cohomology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Criticality in Biology', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Decision Theory', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Global Workspace Theory', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'F-Theory', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Noetic Fiction', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Syntomic Cohomology', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Edge of Chaos', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Game Theory', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Attention Schema Theory', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'AdS/CFT Correspondence', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Cognitive Fiction', time: '14:00 - 15:30' }
    ]
  },
  46: {
    monday: [
      { subject: 'Math', topic: 'Motivic Homotopy Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Self-Organized Criticality', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Quantum Social Science', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Higher-Order Theories', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Gauge/Gravity Duality', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Emergent Narrative', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'A1-Homotopy Theory', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Avalanche Dynamics', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Quantum Probability', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Recurrent Processing Theory', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Holography', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Complexity Fiction', time: '14:00 - 15:30' }
    ]
  },
  47: {
    monday: [
      { subject: 'Math', topic: 'Final Review - Algebra', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Final Review - Life Sciences', time: '14:00 - 15:30' }
    ],
    tuesday: [
      { subject: 'Chemistry', topic: 'Final Review - Chemical Sciences', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Final Review - Language', time: '14:00 - 15:30' }
    ],
    wednesday: [
      { subject: 'Physics', topic: 'Final Review - Physical Sciences', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Final Review - Literary Studies', time: '14:00 - 15:30' }
    ],
    thursday: [
      { subject: 'Math', topic: 'Comprehensive Exam Prep', time: '09:00 - 10:30' },
      { subject: 'Biology', topic: 'Comprehensive Exam Prep', time: '14:00 - 15:30' }
    ],
    friday: [
      { subject: 'Chemistry', topic: 'Comprehensive Exam Prep', time: '09:00 - 10:30' },
      { subject: 'Portuguese', topic: 'Comprehensive Exam Prep', time: '14:00 - 15:30' }
    ],
    saturday: [
      { subject: 'Physics', topic: 'Comprehensive Exam Prep', time: '09:00 - 10:30' },
      { subject: 'Literature', topic: 'Comprehensive Exam Prep', time: '14:00 - 15:30' }
    ]
  }
};