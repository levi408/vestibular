export const subjectColors = {
  Math: {
    bg: 'bg-blue-50',
    border: 'border-blue-500',
    text: 'text-blue-700',
    badge: 'bg-blue-600 text-white',
    progress: 'bg-blue-500'
  },
  Biology: {
    bg: 'bg-green-50',
    border: 'border-green-500',
    text: 'text-green-700',
    badge: 'bg-green-600 text-white',
    progress: 'bg-green-500'
  },
  Chemistry: {
    bg: 'bg-purple-50',
    border: 'border-purple-500',
    text: 'text-purple-700',
    badge: 'bg-purple-600 text-white',
    progress: 'bg-purple-500'
  },
  Portuguese: {
    bg: 'bg-orange-50',
    border: 'border-orange-500',
    text: 'text-orange-700',
    badge: 'bg-orange-600 text-white',
    progress: 'bg-orange-500'
  },
  Physics: {
    bg: 'bg-red-50',
    border: 'border-red-500',
    text: 'text-red-700',
    badge: 'bg-red-600 text-white',
    progress: 'bg-red-500'
  },
  Literature: {
    bg: 'bg-pink-50',
    border: 'border-pink-500',
    text: 'text-pink-700',
    badge: 'bg-pink-600 text-white',
    progress: 'bg-pink-500'
  },
  default: {
    bg: 'bg-gray-50',
    border: 'border-gray-500',
    text: 'text-gray-700',
    badge: 'bg-gray-600 text-white',
    progress: 'bg-gray-500'
  }
};