import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Target, Award, Calendar } from 'lucide-react';
import { studyPlanData } from '@/data/studyPlanData';
import { subjectColors } from '@/data/subjectColors';

const Dashboard = ({ completedSessions, currentWeek, totalWeeks }) => {
  const stats = useMemo(() => {
    let totalSessions = 0;
    let completedCount = 0;
    const subjectProgress = {};

    Object.keys(studyPlanData).forEach(weekNum => {
      const week = studyPlanData[weekNum];
      Object.keys(week).forEach(day => {
        if (Array.isArray(week[day])) {
          week[day].forEach((session, idx) => {
            totalSessions++;
            const key = `${weekNum}-${day}-${idx}`;
            if (completedSessions[key]) {
              completedCount++;
              subjectProgress[session.subject] = (subjectProgress[session.subject] || 0) + 1;
            }
          });
        }
      });
    });

    const overallProgress = totalSessions > 0 ? (completedCount / totalSessions) * 100 : 0;
    const weekProgress = (currentWeek / totalWeeks) * 100;

    return {
      totalSessions,
      completedCount,
      overallProgress,
      weekProgress,
      subjectProgress
    };
  }, [completedSessions, currentWeek, totalWeeks]);

  const statCards = [
    {
      title: 'Overall Progress',
      value: `${stats.overallProgress.toFixed(1)}%`,
      icon: TrendingUp,
      color: 'from-blue-500 to-blue-600',
      description: `${stats.completedCount} of ${stats.totalSessions} sessions`
    },
    {
      title: 'Week Progress',
      value: `Week ${currentWeek}`,
      icon: Calendar,
      color: 'from-green-500 to-green-600',
      description: `${stats.weekProgress.toFixed(1)}% of program`
    },
    {
      title: 'Sessions Completed',
      value: stats.completedCount,
      icon: Award,
      color: 'from-purple-500 to-purple-600',
      description: 'Total completed'
    },
    {
      title: 'Target',
      value: stats.totalSessions,
      icon: Target,
      color: 'from-orange-500 to-orange-600',
      description: 'Total sessions'
    }
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Progress Dashboard</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              <div className={`bg-gradient-to-r ${stat.color} p-4 text-white`}>
                <Icon className="w-8 h-8 mb-2" />
                <h3 className="text-sm font-semibold opacity-90">{stat.title}</h3>
              </div>
              <div className="p-4">
                <p className="text-3xl font-bold text-gray-800 mb-1">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.description}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Subject Progress</h3>
        <div className="space-y-4">
          {Object.entries(stats.subjectProgress).map(([subject, count]) => {
            const color = subjectColors[subject] || subjectColors.default;
            return (
              <div key={subject} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`font-semibold ${color.text}`}>{subject}</span>
                  <span className="text-sm text-gray-600">{count} sessions</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(count / stats.completedCount) * 100}%` }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className={`h-2 rounded-full ${color.progress}`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl p-6 border border-blue-200">
        <h3 className="text-lg font-bold text-blue-900 mb-2">Keep Going! 🎯</h3>
        <p className="text-blue-800">
          You're making great progress! Stay consistent with your study schedule to achieve your goals.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;