import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, CheckCircle2, Circle, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const TaskManager = ({ tasks, setTasks, currentWeek }) => {
  const [newTask, setNewTask] = useState('');
  const [selectedPriority, setSelectedPriority] = useState('medium');
  const { toast } = useToast();

  const addTask = () => {
    if (newTask.trim()) {
      const task = {
        id: Date.now(),
        text: newTask,
        completed: false,
        priority: selectedPriority,
        week: currentWeek,
        createdAt: new Date().toISOString()
      };
      setTasks([...tasks, task]);
      setNewTask('');
      toast({
        title: "Task Added",
        description: "Your task has been added successfully!",
      });
    }
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
    toast({
      title: "Task Deleted",
      description: "Task has been removed from your list.",
    });
  };

  const priorities = [
    { value: 'high', label: 'High', color: 'bg-red-500' },
    { value: 'medium', label: 'Medium', color: 'bg-yellow-500' },
    { value: 'low', label: 'Low', color: 'bg-green-500' }
  ];

  const weekTasks = tasks.filter(task => task.week === currentWeek);
  const allTasks = tasks;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Task Manager</h2>

      <div className="bg-gradient-to-r from-blue-50 to-white rounded-xl p-6 shadow-md border border-blue-100">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Task</h3>
        <div className="space-y-4">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTask()}
            placeholder="Enter task description..."
            className="w-full px-4 py-3 border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-200"
          />
          
          <div className="flex flex-wrap gap-2">
            {priorities.map(priority => (
              <button
                key={priority.value}
                onClick={() => setSelectedPriority(priority.value)}
                className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                  selectedPriority === priority.value
                    ? `${priority.color} text-white shadow-md`
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {priority.label}
              </button>
            ))}
          </div>

          <Button
            onClick={addTask}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Task
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-bold text-gray-800">Week {currentWeek} Tasks</h3>
          </div>
          <div className="space-y-2">
            <AnimatePresence>
              {weekTasks.length > 0 ? (
                weekTasks.map((task) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onToggle={toggleTask}
                    onDelete={deleteTask}
                  />
                ))
              ) : (
                <p className="text-gray-500 text-center py-8">No tasks for this week</p>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">All Tasks</h3>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            <AnimatePresence>
              {allTasks.length > 0 ? (
                allTasks.map((task) => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onToggle={toggleTask}
                    onDelete={deleteTask}
                    showWeek
                  />
                ))
              ) : (
                <p className="text-gray-500 text-center py-8">No tasks yet</p>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};

const TaskItem = ({ task, onToggle, onDelete, showWeek }) => {
  const priorityColors = {
    high: 'border-red-500 bg-red-50',
    medium: 'border-yellow-500 bg-yellow-50',
    low: 'border-green-500 bg-green-50'
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className={`p-3 rounded-lg border-l-4 ${priorityColors[task.priority]} ${
        task.completed ? 'opacity-60' : ''
      } transition-all duration-200`}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-3 flex-1">
          <button
            onClick={() => onToggle(task.id)}
            className="flex-shrink-0 hover:scale-110 transition-transform duration-200"
          >
            {task.completed ? (
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            ) : (
              <Circle className="w-5 h-5 text-gray-400" />
            )}
          </button>
          <div className="flex-1">
            <p className={`text-sm font-medium ${task.completed ? 'line-through text-gray-500' : 'text-gray-800'}`}>
              {task.text}
            </p>
            {showWeek && (
              <p className="text-xs text-gray-500 mt-1">Week {task.week}</p>
            )}
          </div>
        </div>
        <button
          onClick={() => onDelete(task.id)}
          className="flex-shrink-0 p-1 hover:bg-red-100 rounded transition-colors duration-200"
        >
          <Trash2 className="w-4 h-4 text-red-600" />
        </button>
      </div>
    </motion.div>
  );
};

export default TaskManager;