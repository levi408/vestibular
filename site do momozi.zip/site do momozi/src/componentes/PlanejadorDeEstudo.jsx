import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, CheckSquare, TrendingUp, ChevronLeft, ChevronRight } from 'lucide-react';
import Header from '@/components/Header';
import Dashboard from '@/components/Dashboard';
import WeeklyCalendar from '@/components/WeeklyCalendar';
import TaskManager from '@/components/TaskManager';
import { studyPlanData } from '@/data/studyPlanData';

const StudyPlanner = () => {
  const [activeTab, setActiveTab] = useState('calendar');
  const [currentWeek, setCurrentWeek] = useState(1);
  const [tasks, setTasks] = useState([]);
  const [completedSessions, setCompletedSessions] = useState({});

  useEffect(() => {
    const savedTasks = localStorage.getItem('studyTasks');
    const savedSessions = localStorage.getItem('completedSessions');
    if (savedTasks) setTasks(JSON.parse(savedTasks));
    if (savedSessions) setCompletedSessions(JSON.parse(savedSessions));
  }, []);

  useEffect(() => {
    localStorage.setItem('studyTasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('completedSessions', JSON.stringify(completedSessions));
  }, [completedSessions]);

  const tabs = [
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
  ];

  const handlePreviousWeek = () => {
    if (currentWeek > 1) setCurrentWeek(currentWeek - 1);
  };

  const handleNextWeek = () => {
    if (currentWeek < 47) setCurrentWeek(currentWeek + 1);
  };

  const toggleSessionComplete = (weekNum, day, sessionId) => {
    const key = `${weekNum}-${day}-${sessionId}`;
    setCompletedSessions(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  return (
    <div className="min-h-screen">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <nav className="flex border-b border-blue-100 bg-gradient-to-r from-blue-50 to-white">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 flex items-center justify-center gap-2 px-6 py-4 font-semibold transition-all duration-300 ${
                    activeTab === tab.id
                      ? 'text-blue-600 border-b-2 border-blue-600 bg-white'
                      : 'text-gray-600 hover:text-blue-500 hover:bg-blue-50'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </nav>

          <div className="p-6">
            {activeTab === 'calendar' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-gray-800">Week {currentWeek} of 47</h2>
                  <div className="flex gap-2">
                    <button
                      onClick={handlePreviousWeek}
                      disabled={currentWeek === 1}
                      className="p-2 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleNextWeek}
                      disabled={currentWeek === 47}
                      className="p-2 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <WeeklyCalendar 
                  weekNumber={currentWeek} 
                  weekData={studyPlanData[currentWeek]}
                  completedSessions={completedSessions}
                  onToggleSession={toggleSessionComplete}
                />
              </div>
            )}

            {activeTab === 'dashboard' && (
              <Dashboard 
                completedSessions={completedSessions}
                currentWeek={currentWeek}
                totalWeeks={47}
              />
            )}

            {activeTab === 'tasks' && (
              <TaskManager 
                tasks={tasks}
                setTasks={setTasks}
                currentWeek={currentWeek}
              />
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default StudyPlanner;