import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, ExternalLink, FileText, Video, Link as LinkIcon } from 'lucide-react';
import { subjectColors } from '@/data/subjectColors';
import { useToast } from '@/components/ui/use-toast';

const MaterialRepository = ({ currentWeek }) => {
  const { toast } = useToast();
  const [selectedSubject, setSelectedSubject] = useState('all');

  const subjects = ['Math', 'Biology', 'Chemistry', 'Portuguese', 'Physics', 'Literature'];

  const materials = [
    {
      subject: 'Math',
      title: 'Algebra Fundamentals',
      type: 'lesson',
      description: 'Complete guide to algebraic expressions and equations',
      link: '#'
    },
    {
      subject: 'Math',
      title: 'Practice Exercises - Week ' + currentWeek,
      type: 'exercise',
      description: 'Problem sets for current week topics',
      link: '#'
    },
    {
      subject: 'Biology',
      title: 'Cell Structure & Function',
      type: 'lesson',
      description: 'Detailed overview of cellular biology',
      link: '#'
    },
    {
      subject: 'Biology',
      title: 'Lab Exercises',
      type: 'exercise',
      description: 'Hands-on biology experiments',
      link: '#'
    },
    {
      subject: 'Chemistry',
      title: 'Chemical Reactions',
      type: 'video',
      description: 'Video lectures on reaction mechanisms',
      link: '#'
    },
    {
      subject: 'Chemistry',
      title: 'Practice Problems',
      type: 'exercise',
      description: 'Stoichiometry and balancing equations',
      link: '#'
    },
    {
      subject: 'Portuguese',
      title: 'Grammar Guide',
      type: 'lesson',
      description: 'Comprehensive Portuguese grammar reference',
      link: '#'
    },
    {
      subject: 'Portuguese',
      title: 'Reading Comprehension',
      type: 'exercise',
      description: 'Practice texts and questions',
      link: '#'
    },
    {
      subject: 'Physics',
      title: 'Mechanics Fundamentals',
      type: 'lesson',
      description: 'Newton\'s laws and motion principles',
      link: '#'
    },
    {
      subject: 'Physics',
      title: 'Problem Sets',
      type: 'exercise',
      description: 'Physics calculations and applications',
      link: '#'
    },
    {
      subject: 'Literature',
      title: 'Literary Analysis',
      type: 'lesson',
      description: 'Techniques for analyzing texts',
      link: '#'
    },
    {
      subject: 'Literature',
      title: 'Reading List',
      type: 'exercise',
      description: 'Recommended books and essays',
      link: '#'
    }
  ];

  const filteredMaterials = selectedSubject === 'all' 
    ? materials 
    : materials.filter(m => m.subject === selectedSubject);

  const getTypeIcon = (type) => {
    switch(type) {
      case 'lesson': return FileText;
      case 'exercise': return BookOpen;
      case 'video': return Video;
      default: return LinkIcon;
    }
  };

  const handleMaterialClick = (material) => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
      description: `Material: ${material.title}`,
    });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Material Repository</h2>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setSelectedSubject('all')}
          className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
            selectedSubject === 'all'
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          All Subjects
        </button>
        {subjects.map(subject => {
          const color = subjectColors[subject] || subjectColors.default;
          return (
            <button
              key={subject}
              onClick={() => setSelectedSubject(subject)}
              className={`px-4 py-2 rounded-lg font-semibold transition-all duration-200 ${
                selectedSubject === subject
                  ? `${color.badge} shadow-md`
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {subject}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMaterials.map((material, index) => {
          const Icon = getTypeIcon(material.type);
          const color = subjectColors[material.subject] || subjectColors.default;
          
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => handleMaterialClick(material)}
              className={`bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer border-l-4 ${color.border}`}
            >
              <div className={`${color.bg} p-4`}>
                <div className="flex items-center gap-2 mb-2">
                  <Icon className={`w-5 h-5 ${color.text}`} />
                  <span className={`text-xs font-bold px-2 py-1 rounded ${color.badge}`}>
                    {material.subject}
                  </span>
                </div>
                <h3 className="font-bold text-gray-800">{material.title}</h3>
              </div>
              <div className="p-4">
                <p className="text-sm text-gray-600 mb-3">{material.description}</p>
                <div className="flex items-center gap-2 text-blue-600 text-sm font-semibold">
                  <span>Access Material</span>
                  <ExternalLink className="w-4 h-4" />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default MaterialRepository;