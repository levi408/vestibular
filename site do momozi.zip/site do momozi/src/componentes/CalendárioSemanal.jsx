import React from 'react';
import { motion } from 'framer-motion';
import { Clock, CheckCircle2, Circle } from 'lucide-react';
import { subjectColors } from '@/data/subjectColors';

const WeeklyCalendar = ({ weekNumber, weekData, completedSessions, onToggleSession }) => {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  if (!weekData) {
    return (
      <div className="text-center py-12 text-gray-500">
        <p className="text-lg">No data available for this week</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {days.map((day, index) => {
        const dayData = weekData[day.toLowerCase()];
        
        return (
          <motion.div
            key={day}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gradient-to-br from-white to-blue-50 rounded-xl shadow-md border border-blue-100 overflow-hidden hover:shadow-lg transition-shadow duration-300"
          >
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 py-3">
              <h3 className="font-bold text-lg">{day}</h3>
            </div>
            
            <div className="p-4 space-y-3">
              {dayData && dayData.length > 0 ? (
                dayData.map((session, idx) => {
                  const sessionKey = `${weekNumber}-${day.toLowerCase()}-${idx}`;
                  const isCompleted = completedSessions[sessionKey];
                  const color = subjectColors[session.subject] || subjectColors.default;
                  
                  return (
                    <motion.div
                      key={idx}
                      whileHover={{ scale: 1.02 }}
                      className={`p-3 rounded-lg border-l-4 ${color.border} ${color.bg} cursor-pointer transition-all duration-200 ${
                        isCompleted ? 'opacity-60' : ''
                      }`}
                      onClick={() => onToggleSession(weekNumber, day.toLowerCase(), idx)}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`text-xs font-bold px-2 py-1 rounded ${color.badge}`}>
                              {session.subject}
                            </span>
                            {isCompleted ? (
                              <CheckCircle2 className="w-4 h-4 text-green-600" />
                            ) : (
                              <Circle className="w-4 h-4 text-gray-400" />
                            )}
                          </div>
                          <p className="text-sm font-semibold text-gray-800 mb-1">
                            {session.topic}
                          </p>
                          <div className="flex items-center gap-1 text-xs text-gray-600">
                            <Clock className="w-3 h-3" />
                            <span>{session.time}</span>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">No sessions scheduled</p>
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};

export default WeeklyCalendar;